#ifndef _GENERUJ_H_
#define _GENERUJ_H_

void generujtekst(int);
char nastepnalitera(char, char, char);

#endif
