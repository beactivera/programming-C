#include<stdio.h>
#include<stdlib.h> /* rand */
#include<time.h>   /* time */
#include"globalne.h"

char nastepnalitera(char c3, char c2, char c1)
{
    int suma = 0;
    for (int i=0; i<128; i++)
        suma += t[c3][c2][c1][i];

    if (suma==0) return '?';
    
    int los = rand()%suma;
    for (int i=0; i<128; i++)
    {
        los -= t[c3][c2][c1][i];
        if (los<0) 
            return i;
    }    
}

void generujtekst(int dl)
{
    srand(time(NULL));
    dl-=3;
    printf("the"); 
    char c3 = 't';
    char c2 = 'h';
    char c1 = 'e';
    while (dl>0)
    {
        char nowa = nastepnalitera(c3,c2,c1);
        printf("%c", nowa);
        c3=c2;
        c2=c1;
        c1=nowa;        
        dl--;
    }
    printf("\n");
}

