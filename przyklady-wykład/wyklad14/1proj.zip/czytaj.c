#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdbool.h>
#include"globalne.h"

bool dobryznak(char c)
{
    if ((c>='a' && c<='z') || c==' ')
        return true;
    return false;
}

char wczytajznak(FILE *f, char pop)
{
    char c;
    do
    {
       c = fgetc(f);
       c = tolower(c);
       if (c!=EOF && !dobryznak(c)) c = ' ';       
    }
    while (c!=EOF && (c==pop && pop==' '));
    return c;
}

bool wczytajplik()
{
    memset(t,0,sizeof(t));

    FILE *f = fopen("dane.txt","rt");
    if (f == NULL) return false;
    
    char c4=wczytajznak(f, '!');
    if (c4 == EOF) return false;
    char c3=wczytajznak(f, c4);
    if (c3 == EOF) return false;
    char c2=wczytajznak(f, c3);
    if (c2 == EOF) return false;
    char c1=wczytajznak(f, c2);
    if (c1 == EOF) return false;

    do 
    {
        t[c4][c3][c2][c1]++;
        c4=c3;
        c3=c2;
        c2=c1;
    }    
    while((c1=wczytajznak(f,c1)) != EOF);
    
    fclose(f);
    return true;
}

