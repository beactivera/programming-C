#ifndef _GLOBALNE_H_
#define _GLOBALNE_H_

int t[128][128][128][128];

#endif