#include<stdio.h>
#include"czytaj.h"
#include"generuj.h"

int main()
{    
    if (!wczytajplik())
    {
        printf("Blad wczytywania danych\n");
        return 1;
    }

    generujtekst(1000);
    return 0;
}

