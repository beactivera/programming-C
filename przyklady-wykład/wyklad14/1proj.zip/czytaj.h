#ifndef _CZYTAJ_H_
#define _CZYTAJ_H_

#include<stdbool.h>

bool dobryznak(char c);
char wczytajznak(FILE *, char);
bool wczytajplik();

#endif
